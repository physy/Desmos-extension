This extension includes the following fonts:

- Latin Modern Math (LMMath-Regular)
- Latin Modern Roman (LMRoman10-Regular, LMRoman10-Italic)

These fonts are licensed under the GUST Font License.
